# SecureDocs — 100-Case Synthetic Document Dataset

## Purpose
This dataset was generated as **synthetic / fictional demo data** to test the
SecureDocs Secure Digital Document Management System prototype. It contains
no real people, real case numbers, or real law-enforcement records of any kind.
All names, dates, officers, evidence, and outcomes are fictional and derived
solely from the accompanying master spreadsheet (`fake_case_records.xlsx`),
which was treated as the single source of truth for all case-level facts.

## Contents
- **100 cases**, each with **5 documents** = **500 documents total**
- Document types per case:
  1. First Information Report (FIR)
  2. Witness Statement
  3. Evidence Seizure Report (Seizure Mahazar)
  4. Investigation Report
  5. Forensic Examination Report

## Folder Structure
```
SecureDocs_100_Case_Dataset/
├── Case_001_CR-2023-1001/
│   ├── CR-2023-1001_FIR.docx
│   ├── CR-2023-1001_Witness_Statement.docx
│   ├── CR-2023-1001_Seizure_Report.docx
│   ├── CR-2023-1001_Investigation_Report.docx
│   └── CR-2023-1001_Forensic_Report.docx
├── Case_002_.../
├── ...
├── README.md
└── case_document_index.csv
```

## Naming Convention
`<CaseNumber>_<DocumentType>.docx`, e.g. `CR-2023-1001_FIR.docx`.

## Case–Document Relationships
For every case, the five documents describe **one consistent fictional
incident**: the same victim, suspect(s), witness(es), investigating officer,
badge number, date/location, case type, evidence IDs/descriptions, and
case/court status are carried through the FIR → Witness Statement → Seizure
Report → Investigation Report → Forensic Report. Evidence items are assigned
IDs of the form `EV-<CaseNumberNoDash>-NNN` and referenced identically across
the Seizure, Investigation, and Forensic reports. Investigation conclusions
and any court/legal-proceedings section are consistent with the `Status` and
`Went to Court` fields in the master spreadsheet.

## Synthetic Data Disclaimer
**This entire dataset is fictional and was generated programmatically for
software testing purposes only.** It does not represent, and must not be
used to represent, any real investigation, real person, or real law-
enforcement record. No real Aadhaar numbers, phone numbers, addresses, bank
details, or government IDs appear anywhere in the dataset.

## Index File
`case_document_index.csv` provides a master index of all 500 documents with
columns: Case Number, Case Type, Document Type, File Name, Victim, Suspect,
IO, Status, Evidence IDs, Forensic Report No. — intended to simplify import
into the SecureDocs application.

## Generation Summary
- Cases: 100
- FIRs: 100
- Witness Statements: 100
- Seizure Reports: 100
- Investigation Reports: 100
- Forensic Reports: 100
- **Total documents: 500**
